﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BancoApp.Data.Migrations
{
    /// <inheritdoc />
    public partial class CuentaMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
